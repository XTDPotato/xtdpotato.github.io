#include<regx51.h>
#define uchar unsigned char
#define uint unsigned int
uint temp=0;
uchar code tab[5]={0x40,0x77,0x7c,0x39,0x5e};
void delay(int x){
	uchar j;
	while(--x)
		for(j=0;j<254;j++);			   	

}
void init(){
	EA=1;
	EX0=1;
	EX1=1;
	IT1=1;
	IT0=1;
	//TCON=0xf0;

}
void main(){
	init();
	while(1){
		P0=tab[temp];
		switch(temp){
			case 1:P3_0=0;delay(500);P0=0x00;P3_0=1;delay(500);break;
			case 2:P3_0=0;delay(350);P0=0x00;P3_0=1;delay(350);break;
			case 3:P3_0=0;delay(200);P0=0x00;P3_0=1;delay(200);break;
			case 4:P3_0=0;delay(50);P0=0x00;P3_0=1;delay(50);break;
			default:break;		
		}
	}

}



void int_0() interrupt 0 using 1{
	EA=0;
	delay(255);
	temp++;
	if(temp==5)
		temp=4;
	EA=1;

}	

void int_1() interrupt 2 using 1{
	EA=0;
	delay(255);
	if(temp>0)
		temp--;
	EA=1;

}	



