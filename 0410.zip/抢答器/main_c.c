#include<regx51.h>
#define uchar unsigned char
#define uint unsigned int
uint temp=0;
uchar code num[10]={0x3f,0x06,0x5b,0x4f,0x66,
					0x6d,0x7d,0x07,0x7f,0x6f};


void delay(int x){
	uchar j;
	while(--x)
		for(j=0;j<254;j++);			   	

}
void init(){
	EA=1;
	//TCON;
	EX0=1;
	EX1=1;
	IT1=1;
	IT0=1;
	

}
void main(){
	init();
	while(1){
	P2=0X00;
		P1=num[temp];
		}
}



void int_0() interrupt 0 using 1{
	EA=0;
	delay(255);
	temp++;
	if(temp>=9)
		temp=9;
	EA=1;

}	

void int_1() interrupt 2 using 1{
	EA=0;
	delay(255);
	if(temp>0)
		temp--;
	EA=1;

}	



